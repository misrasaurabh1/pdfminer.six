from .pdfminer_core import *

__doc__ = pdfminer_core.__doc__
if hasattr(pdfminer_core, "__all__"):
    __all__ = pdfminer_core.__all__